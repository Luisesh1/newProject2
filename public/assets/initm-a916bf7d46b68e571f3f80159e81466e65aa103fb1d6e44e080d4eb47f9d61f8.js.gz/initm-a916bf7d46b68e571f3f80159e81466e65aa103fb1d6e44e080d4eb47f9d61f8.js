$(document).ready(function (){
   $('.parallax').parallax();
   $(".button-collapse").sideNav();
  });
 TweenMax.staggerFrom(".card", 1, {alpha:0.5,scale:0.5}, .6);
  
