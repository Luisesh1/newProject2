   $('.parallax').parallax();
   $(".button-collapse").sideNav();
  
